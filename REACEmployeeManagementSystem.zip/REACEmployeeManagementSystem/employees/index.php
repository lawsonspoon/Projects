<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REAC Employee Management System</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Manage Employees</h2>

        <div class="mt-4">
            <form action="create.php" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" name="username" id="username" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" id="name" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" name="address" id="address" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="salary">Salary</label>
                        <input type="number" class="form-control" name="salary" id="salary" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="birth_date">Date of Birth</label>
                        <input type="date" class="form-control" name="birth_date" id="birth_date" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="gender">Gender</label>
                        <select name="gender" class="form-control" id="gender" required>
                            <option value="">--Select Gender--</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="image">Image</label>
                        <input type="file" class="form-control" name="image" id="image" accept="image/*" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="hire_date">Hire Date</label>
                        <input type="date" class="form-control" name="hire_date" id="hire_date" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Add Employee</button>
            </form>
        </div>

        <!-- User Table -->
        <div class="mt-5">
            <h2 class="text-center">List of Employees</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Address</th>
                        <th>Salary</th>
                        <th>Date of Birth</th>
                        <th>Image</th>
                        <th>Gender</th>
                        <th>Hire Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include 'conn.php';
                    $sql = "SELECT * FROM employee";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>{$row['id']}</td>
                                    <td>{$row['username']}</td>
                                    <td>{$row['name']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['address']}</td>
                                    <td>{$row['salary']}</td>
                                    <td>{$row['birth_date']}</td>
                                    <td>{$row['image']}</td>
                                    <td>{$row['gender']}</td>
                                    <td>{$row['hire_date']}</td>
                                    <td>
                                        <a href='update.php?id={$row['id']}' class='btn btn-warning'>Edit</a>
                                        <a href='delete.php?id={$row['id']}' class='btn btn-danger'>Delete</a>
                                    </td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='11' class='text-center'>No employees found</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
