<?php
include 'conn.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM employee WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update User</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Update Employee</h2>
        <div class="mt-4">
            <form action="update.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data">
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="username">Username</label>
                        <input type="text" class="form-control" name="username" id="username" value="<?= $row['username'] ?>" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" name="name" id="name" value="<?= $row['name'] ?>" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" value="<?= $row['email'] ?>" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="address">Address</label>
                        <input type="text" class="form-control" name="address" id="address" value="<?= $row['address'] ?>" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="salary">Salary</label>
                        <input type="number" class="form-control" name="salary" id="salary" value="<?= $row['salary'] ?>" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="birth_date">Date of Birth</label>
                        <input type="date" class="form-control" name="birth_date" id="birth_date" value="<?= $row['birth_date'] ?>" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="gender">Gender</label>
                        <select class="form-control" name="gender" id="gender" required>
                            <option value="">--Select Gender--</option>
                            <option value="Male" <?= ($row['gender'] == 'Male') ? 'selected' : '' ?>>Male</option>
                            <option value="Female" <?= ($row['gender'] == 'Female') ? 'selected' : '' ?>>Female</option>
                            <option value="Other" <?= ($row['gender'] == 'Other') ? 'selected' : '' ?>>Other</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="image">Image</label>
                        <input type="file" class="form-control" name="image" id="image" accept="image/*" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="hire_date">Hire Date</label>
                        <input type="date" class="form-control" name="hire_date" id="hire_date" value="<?= $row['hire_date'] ?>" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Update Employee</button>
            </form>
        </div>
    </div>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username']; // Get the username
    $name = $_POST['name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $salary = $_POST['salary'];
    $birth_date = date('Ymd', strtotime($_POST['birth_date']));
    $gender = $_POST['gender'];
    $image = $_FILES['image']['name']; // Update to use $_FILES for the image
    $hire_date = date('Ymd', strtotime($_POST['hire_date']));

    // Handle the image upload if a new image is provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        $imageExt = strtolower(pathinfo($image, PATHINFO_EXTENSION));

        if (in_array($imageExt, $allowedExtensions) && $_FILES['image']['size'] <= 5000000) {
            $newImageName = uniqid() . '.' . $imageExt;
            move_uploaded_file($_FILES['image']['tmp_name'], 'uploads/' . $newImageName);
            $image = $newImageName; // Use the new image name
        } else {
            echo "<p style='color:red;'>Invalid image file type or size.</p>";
        }
    } else {
        // Keep the old image if no new image is uploaded
        $image = $row['image'];
    }

    $sql = "UPDATE employee SET username='$username', name='$name', email='$email', address='$address', salary='$salary', birth_date='$birth_date', gender='$gender', image='$image', hire_date='$hire_date' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
