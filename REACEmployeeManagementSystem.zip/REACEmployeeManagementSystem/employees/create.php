<?php
include 'conn.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Initialize error array
    $errors = [];

    // Username validation
    $username = trim($_POST['username']);
    if (empty($username) || !preg_match("/^[a-zA-Z0-9_]*$/", $username)) {
        $errors[] = 'Username is required and can only contain letters, numbers, and underscores.';
    }

    // Name validation
    $name = trim($_POST['name']);
    if (empty($name) || !preg_match("/^[a-zA-Z ]*$/", $name)) {
        $errors[] = 'Name is required or Invalid name.';
    }

    // Email validation
    $email = trim($_POST['email']);
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email is required or Invalid email address.';
    }

    // Address validation
    $address = trim($_POST['address']);
    if (empty($address)) {
        $errors[] = 'Address is required.';
    }

    // Salary validation
    $salary = $_POST['salary'];
    if (!is_numeric($salary) || $salary <= 0) {
        $errors[] = 'Salary must be a positive number.';
    }

    // Date of birth validation
    $birth_date = trim($_POST['birth_date']);
    // Convert the birth_date into a timestamp
    $birthDateTimestamp = strtotime($birth_date);
    // Get current date
    $currentDate = date('Y-m-d');
    $currentYear = date('Y');

    // Calculate the age
    $birthYear = date('Y', $birthDateTimestamp);
    $age = $currentYear - $birthYear;

    if (empty($birth_date) || $age < 18) {
        $errors[] = 'Date of birth is required and must indicate at least 18 years of age.';
    }

    // Gender validation
    $gender = $_POST['gender'];
    $validGenders = ['Male', 'Female', 'Other'];
    if (!in_array($gender, $validGenders)) {
        $errors[] = 'Invalid gender selection.';
    }

    // Hire date validation
    $hire_date = $_POST['hire_date'];
    if (empty($hire_date)) {
        $errors[] = 'Hire date is required.';
    }

    // Image validation
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $image = $_FILES['image'];
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
        $imageExt = strtolower(pathinfo($image['name'], PATHINFO_EXTENSION));

        if (!in_array($imageExt, $allowedExtensions)) {
            $errors[] = 'Invalid image file type. Allowed: jpg, jpeg, png, gif.';
        }

        if ($image['size'] > 5000000) { // 5MB limit
            $errors[] = 'Image size must be less than 5MB.';
        }
    } else {
        $errors[] = 'Please upload an image.';
    }

    // If no errors, process the form
    if (empty($errors)) {
        // Move the uploaded image
        $newImageName = uniqid() . '.' . $imageExt;
        move_uploaded_file($image['tmp_name'], 'uploads/' . $newImageName);

        // Sanitize input before inserting into the database
        $username = $conn->real_escape_string($username);
        $name = $conn->real_escape_string($name);
        $email = $conn->real_escape_string($email);
        $address = $conn->real_escape_string($address);
        $salary = (float) $salary;
        $birth_date = date('Ymd', strtotime($birth_date));
        $hire_date = date('Ymd', strtotime($hire_date));

        // Insert into the database
        $sql = "INSERT INTO employee (username, name, email, address, salary, birth_date, gender, image, hire_date) 
                VALUES ('$username', '$name', '$email', '$address', $salary, '$birth_date', '$gender', '$newImageName', '$hire_date')";

        if ($conn->query($sql) === TRUE) {
            // Get the last inserted employee ID
            $employeeId = $conn->insert_id; // Retrieve the last inserted ID

            // Echo the employee ID
            echo "Employee added successfully! Employee ID: " . $employeeId;
            // Redirect to index.php after successful insertion
            header("Location: http://localhost/REACEmployeeManagementSystem/login.php");
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    } else {
        // Display validation errors
        foreach ($errors as $error) {
            echo "<p style='color:red;'>$error</p>";
        }
    }
}
?>
